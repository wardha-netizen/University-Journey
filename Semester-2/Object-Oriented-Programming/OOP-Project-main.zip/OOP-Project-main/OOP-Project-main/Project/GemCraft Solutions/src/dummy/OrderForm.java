package dummy;

import database.DBConnection;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.*;

public class OrderForm extends JFrame {
    private JTextField customerNameField, customerPhoneField, customerAddressField;
    private JPanel itemsPanel;
    private JButton addItemButton, submitOrderButton;
    private JLabel totalLabel;
    private JComboBox<String> itemComboBox;
    private JTextField quantityField, priceField;
    private ArrayList<ItemSelection> itemSelections;

    public OrderForm() {
        setTitle("Point of Sale");
        setSize(600, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        itemSelections = new ArrayList<>();

        JPanel customerPanel = new JPanel(new GridLayout(3, 2));
        customerNameField = new JTextField();
        customerPhoneField = new JTextField();
        customerAddressField = new JTextField();

        customerPanel.add(new JLabel("Customer Name:"));
        customerPanel.add(customerNameField);
        customerPanel.add(new JLabel("Phone Number:"));
        customerPanel.add(customerPhoneField);
        customerPanel.add(new JLabel("Address:"));
        customerPanel.add(customerAddressField);

        itemsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        itemComboBox = new JComboBox<>();
        quantityField = new JTextField(5);
        priceField = new JTextField(8);
        priceField.setEditable(false);

        loadItems();

        itemsPanel.add(new JLabel("Item:"));
        itemsPanel.add(itemComboBox);
        itemsPanel.add(new JLabel("Quantity:"));
        itemsPanel.add(quantityField);
        itemsPanel.add(new JLabel("Price:"));
        itemsPanel.add(priceField);

        itemComboBox.addActionListener(e -> updatePrice());

        JScrollPane scrollPane = new JScrollPane(itemsPanel);
        scrollPane.setPreferredSize(new Dimension(550, 100));

        addItemButton = new JButton("Add Item");
        submitOrderButton = new JButton("Submit Order");
        totalLabel = new JLabel("Total: 0.00");

        addItemButton.addActionListener(e -> addItemSelection());
        submitOrderButton.addActionListener(e -> submitOrder());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(totalLabel);
        buttonPanel.add(addItemButton);
        buttonPanel.add(submitOrderButton);

        add(customerPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void loadItems() {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT name, price FROM items";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                itemComboBox.addItem(rs.getString("name"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void updatePrice() {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT price FROM items WHERE name = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, (String) itemComboBox.getSelectedItem());
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                priceField.setText(String.valueOf(rs.getDouble("price")));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void addItemSelection() {
        String itemName = (String) itemComboBox.getSelectedItem();
        int quantity = Integer.parseInt(quantityField.getText());
        double price = Double.parseDouble(priceField.getText());

        itemSelections.add(new ItemSelection(itemName, quantity, price));
        totalLabel.setText("Total: " + calculateTotal());
        JOptionPane.showMessageDialog(this, "Item Added: " + itemName + " x" + quantity);
    }

    private double calculateTotal() {
        return itemSelections.stream().mapToDouble(i -> i.price * i.quantity).sum();
    }

    private void submitOrder() {
        String name = customerNameField.getText();
        String phone = customerPhoneField.getText();
        String address = customerAddressField.getText();

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            String customerQuery = "INSERT INTO customers (name, phone_number, address) VALUES (?, ?, ?)";
            PreparedStatement customerStmt = conn.prepareStatement(customerQuery, Statement.RETURN_GENERATED_KEYS);
            customerStmt.setString(1, name);
            customerStmt.setString(2, phone);
            customerStmt.setString(3, address);
            customerStmt.executeUpdate();

            ResultSet customerRs = customerStmt.getGeneratedKeys();
            customerRs.next();
            int customerId = customerRs.getInt(1);

            String orderQuery = "INSERT INTO orders (customer_id) VALUES (?)";
            PreparedStatement orderStmt = conn.prepareStatement(orderQuery, Statement.RETURN_GENERATED_KEYS);
            orderStmt.setInt(1, customerId);
            orderStmt.executeUpdate();

            ResultSet orderRs = orderStmt.getGeneratedKeys();
            orderRs.next();
            int orderId = orderRs.getInt(1);

            for (ItemSelection selection : itemSelections) {
                String orderItemQuery = "INSERT INTO order_items (order_id, item_id, quantity, price) VALUES (?, (SELECT item_id FROM items WHERE name = ?), ?, ?)";
                PreparedStatement orderItemStmt = conn.prepareStatement(orderItemQuery);
                orderItemStmt.setInt(1, orderId);
                orderItemStmt.setString(2, selection.name);
                orderItemStmt.setInt(3, selection.quantity);
                orderItemStmt.setDouble(4, selection.price);
                orderItemStmt.executeUpdate();
            }

            conn.commit();
            JOptionPane.showMessageDialog(this, "Order placed successfully!");
            itemSelections.clear();
            totalLabel.setText("Total: 0.00");

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error placing order.");
        }
    }

    private class ItemSelection {
        String name;
        int quantity;
        double price;

        ItemSelection(String name, int quantity, double price) {
            this.name = name;
            this.quantity = quantity;
            this.price = price;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OrderForm());
    }
}
