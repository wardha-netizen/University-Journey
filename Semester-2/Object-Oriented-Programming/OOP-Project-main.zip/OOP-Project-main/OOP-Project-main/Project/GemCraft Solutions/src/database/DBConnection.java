package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/jewelrystore"; 
    private static final String USERNAME = "root"; 
    private static final String PASSWORD = "admin";    

    private static Connection connection = null;

    private DBConnection() {}

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {  // <-- Added isClosed check here
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                System.out.println("✅ Database connected successfully.");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("⚠️ MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("⚠️ Database connection failed.");
            e.printStackTrace();
        }
        return connection;
    }
}
