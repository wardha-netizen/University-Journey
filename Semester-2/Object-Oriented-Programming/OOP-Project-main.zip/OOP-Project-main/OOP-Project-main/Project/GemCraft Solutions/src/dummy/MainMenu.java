package dummy;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainMenu extends JFrame {
    private JButton inventoryButton, orderButton, orderManagementButton, customerManagementButton;
    private JPanel mainPanel;

    public MainMenu() {
        setTitle("Jewelry Store Management - Main Menu");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize the buttons
        inventoryButton = new JButton("Manage Inventory");
        orderButton = new JButton("Take Order");
        orderManagementButton = new JButton("Order Management");
        customerManagementButton = new JButton("Customer Management");

        // Action listeners for buttons
        inventoryButton.addActionListener(e -> openInventoryForm());
        orderButton.addActionListener(e -> openOrderForm());
        orderManagementButton.addActionListener(e -> openOrderManagementForm());
        customerManagementButton.addActionListener(e -> openCustomerManagementForm());

        // Panel to organize the buttons
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(4, 1));  // 5 buttons in a vertical layout
        mainPanel.add(inventoryButton);
        mainPanel.add(orderButton);
        mainPanel.add(orderManagementButton);
        mainPanel.add(customerManagementButton);

        // Add the main panel to the frame
        add(mainPanel, BorderLayout.CENTER);

        // Set visibility
        setVisible(true);
    }

    private void openInventoryForm() {
        // Open the Inventory Management Form
        new InventoryForm();
    }

    private void openOrderForm() {
        // Open the Order Form (You should have a method for this)
        new OrderForm();
    }

    private void openOrderManagementForm() {
        // Open the Order Management Form (You should have a method for this)
        new OrderManagementForm();
    }

    private void openCustomerManagementForm() {
        // Open the Receipt Form (You should have a method for this)
        new CustomerManagementForm();
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainMenu());
    }
}
