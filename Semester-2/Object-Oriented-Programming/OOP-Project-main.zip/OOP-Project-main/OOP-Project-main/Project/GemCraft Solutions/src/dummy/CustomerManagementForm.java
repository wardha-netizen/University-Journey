package dummy;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import database.DBConnection; // Assuming you have this.

public class CustomerManagementForm extends JFrame {

    private JTextField nameField, phoneField, addressField;
    private JButton addButton, editButton, deleteButton;
    private JTable customerTable;
    private DefaultTableModel tableModel;
    private JPanel buttonPanel;

    public CustomerManagementForm() {
        setTitle("Customer Management");
        setSize(800, 600); // Increased size for better layout
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10)); // Added layout with gaps

        // Initialize components
        nameField = new JTextField(20);
        phoneField = new JTextField(15);
        addressField = new JTextField(30);
        addButton = new JButton("Add Customer");
        editButton = new JButton("Edit Customer");
        deleteButton = new JButton("Delete Customer");

        // Set Edit and Delete buttons to be disabled initially.
        editButton.setEnabled(false);
        deleteButton.setEnabled(false);

        // Table setup
        tableModel = new DefaultTableModel();
        customerTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(customerTable);

        // Define columns for the table
        tableModel.addColumn("Customer ID");
        tableModel.addColumn("Name");
        tableModel.addColumn("Phone Number");
        tableModel.addColumn("Address");

        // Load initial data into the table
        loadCustomers();

        // Layout
        JPanel inputPanel = new JPanel(new GridBagLayout()); // Using GridBagLayout for more control
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Add padding around components

        // Add labels and text fields to the input panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1;
        inputPanel.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Phone Number:"), gbc);
        gbc.gridx = 1;
        inputPanel.add(phoneField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        inputPanel.add(new JLabel("Address:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;  // Span two columns
        inputPanel.add(addressField, gbc);
        gbc.gridwidth = 1; // Reset to one column

        // Button panel
        buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        // Add components to the frame
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Add action listeners to the buttons
        addButton.addActionListener(e -> addCustomer());
        editButton.addActionListener(e -> editCustomer());
        deleteButton.addActionListener(e -> deleteCustomer());

        // Add mouse listener to the table to enable/disable buttons
        customerTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = customerTable.getSelectedRow();
                if (selectedRow != -1) {
                    editButton.setEnabled(true);
                    deleteButton.setEnabled(true);
                } else {
                    editButton.setEnabled(false);
                    deleteButton.setEnabled(false);
                }
            }
        });

        setVisible(true);
    }

    private void loadCustomers() {
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM customers")) {

            // Clear the table before loading data
            tableModel.setRowCount(0);

            while (rs.next()) {
                int customerId = rs.getInt("customer_id");
                String name = rs.getString("name");
                String phoneNumber = rs.getString("phone_number");
                String address = rs.getString("address");
                tableModel.addRow(new Object[]{customerId, name, phoneNumber, address});
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading customers from the database.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addCustomer() {
        String name = nameField.getText();
        String phoneNumber = phoneField.getText();
        String address = addressField.getText();

        if (name.isEmpty() || phoneNumber.isEmpty() || address.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String query = "INSERT INTO customers (name, phone_number, address) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, name);
            pstmt.setString(2, phoneNumber);
            pstmt.setString(3, address);
            pstmt.executeUpdate();

            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            int newCustomerId = -1;
            if (generatedKeys.next()) {
                newCustomerId = generatedKeys.getInt(1);
            }

            // Add the new customer to the table
            tableModel.addRow(new Object[]{newCustomerId, name, phoneNumber, address});

            // Clear input fields
            nameField.setText("");
            phoneField.setText("");
            addressField.setText("");

            JOptionPane.showMessageDialog(this, "Customer added successfully.");
            loadCustomers();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding customer to the database.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editCustomer() {
        int selectedRow = customerTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a customer to edit.", "Selection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int customerId = (int) tableModel.getValueAt(selectedRow, 0);
        String name = nameField.getText();
        String phoneNumber = phoneField.getText();
        String address = addressField.getText();

        if (name.isEmpty() || phoneNumber.isEmpty() || address.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String query = "UPDATE customers SET name = ?, phone_number = ?, address = ? WHERE customer_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setString(2, phoneNumber);
            pstmt.setString(3, address);
            pstmt.setInt(4, customerId);
            pstmt.executeUpdate();

            // Update the table
            tableModel.setValueAt(name, selectedRow, 1);
            tableModel.setValueAt(phoneNumber, selectedRow, 2);
            tableModel.setValueAt(address, selectedRow, 3);

            // Clear input fields
            nameField.setText("");
            phoneField.setText("");
            addressField.setText("");

            JOptionPane.showMessageDialog(this, "Customer information updated successfully.");
            loadCustomers();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating customer information in the database.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteCustomer() {
        int selectedRow = customerTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a customer to delete.", "Selection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int customerId = (int) tableModel.getValueAt(selectedRow, 0);

        int confirmation = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this customer?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
        if (confirmation != JOptionPane.YES_OPTION) {
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String checkOrderQuery = "SELECT COUNT(*) FROM orders WHERE customer_id = ?";
            PreparedStatement checkOrderStmt = conn.prepareStatement(checkOrderQuery);
            checkOrderStmt.setInt(1, customerId);
            ResultSet orderRs = checkOrderStmt.executeQuery();
            orderRs.next();
            int orderCount = orderRs.getInt(1);

            if (orderCount > 0) {
                JOptionPane.showMessageDialog(this, "Cannot delete customer.  There are existing orders associated with this customer.  Delete the orders first.", "Deletion Error", JOptionPane.ERROR_MESSAGE);
                return; // Stop the deletion process
            }
            
            String query = "DELETE FROM customers WHERE customer_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, customerId);
            pstmt.executeUpdate();

            // Remove the customer from the table
            tableModel.removeRow(selectedRow);

            // Clear input fields
            nameField.setText("");
            phoneField.setText("");
            addressField.setText("");
            editButton.setEnabled(false);
            deleteButton.setEnabled(false);

            JOptionPane.showMessageDialog(this, "Customer deleted successfully.");
            loadCustomers();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting customer from the database.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CustomerManagementForm());
    }
}

