/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gui;
import database.DBConnection;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.*;



public class orderForm1 extends javax.swing.JFrame {
    private double orderTotal = 0.0;
    class OrderItem {
        String itemName;
        int quantity;

        OrderItem(String itemName, int quantity) {
            this.itemName = itemName;
            this.quantity = quantity;
        }
    }

    ArrayList<OrderItem> itemsList = new ArrayList<>();
    private ArrayList<ItemSelection> itemSelections = new ArrayList<>(); // Paste here
    
    
    private void loadItemsFromDatabase() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            stmt = conn.createStatement();
            String sql = "SELECT name FROM items";
            rs = stmt.executeQuery(sql);

            itemSelection.removeAllItems();
            while (rs.next()) {
                itemSelection.addItem(rs.getString("name"));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading items from database.", "Database Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    private double getItemPrice(String itemName) { // Paste the getItemPrice method here
        double price = -1;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT price FROM items WHERE name = ?")) {
            stmt.setString(1, itemName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                price = rs.getDouble("price");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error retrieving item price.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
        return price;
    }
    
    private class ItemSelection { // Paste the ItemSelection inner class here
        String name;
        int quantity;
        double price;

        ItemSelection(String name, int quantity, double price) {
            this.name = name;
            this.quantity = quantity;
            this.price = price;
        }
    }

    private boolean isInitializing = true;
            
    public orderForm1() {
        initComponents();
        loadItemsFromDatabase();
        isInitializing = false;
        setLocationRelativeTo(null);

    }
 
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel2 = new com.k33ptoo.components.KGradientPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        itemSelection = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        totalLabel = new javax.swing.JLabel();
        phoneNumberField = new app.bolivia.swing.JCTextField();
        jLabel21 = new javax.swing.JLabel();
        customerNameField1 = new app.bolivia.swing.JCTextField();
        jLabel22 = new javax.swing.JLabel();
        customerAddressField = new app.bolivia.swing.JCTextField();
        addlabel = new javax.swing.JLabel();
        addItemButton = new rojerusan.RSButtonHover();
        submitorderButton = new rojerusan.RSButtonHover();
        quantityField = new app.bolivia.swing.JCTextField();
        priceField = new app.bolivia.swing.JCTextField();
        b5 = new rojerusan.RSButtonHover();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        kGradientPanel2.setkBorderRadius(0);
        kGradientPanel2.setkEndColor(new java.awt.Color(255, 153, 51));
        kGradientPanel2.setkStartColor(new java.awt.Color(102, 51, 0));
        kGradientPanel2.setRequestFocusEnabled(false);

        jLabel6.setFont(new java.awt.Font("Script MT Bold", 1, 48)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Order Details");

        jLabel5.setBackground(new java.awt.Color(255, 153, 0));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("     Item");
        jLabel5.setOpaque(true);

        itemSelection.setBackground(new java.awt.Color(102, 51, 0));
        itemSelection.setForeground(new java.awt.Color(255, 255, 255));
        itemSelection.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        itemSelection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemSelectionActionPerformed(evt);
            }
        });

        jLabel4.setBackground(new java.awt.Color(255, 153, 0));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("   Quantity");
        jLabel4.setOpaque(true);

        jLabel7.setBackground(new java.awt.Color(255, 153, 0));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("   Price");
        jLabel7.setOpaque(true);

        totalLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        totalLabel.setForeground(new java.awt.Color(255, 255, 255));
        totalLabel.setText("Total: Rs 0.00");

        phoneNumberField.setBackground(new java.awt.Color(102, 51, 0));
        phoneNumberField.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(255, 255, 255)));
        phoneNumberField.setForeground(new java.awt.Color(255, 255, 255));
        phoneNumberField.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        phoneNumberField.setPhColor(new java.awt.Color(255, 255, 255));
        phoneNumberField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneNumberFieldActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Customer Name:");

        customerNameField1.setBackground(new java.awt.Color(102, 51, 0));
        customerNameField1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(255, 255, 255)));
        customerNameField1.setForeground(new java.awt.Color(255, 255, 255));
        customerNameField1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        customerNameField1.setPhColor(new java.awt.Color(255, 255, 255));
        customerNameField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customerNameField1ActionPerformed(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Phone Number:");

        customerAddressField.setBackground(new java.awt.Color(102, 51, 0));
        customerAddressField.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(255, 255, 255)));
        customerAddressField.setForeground(new java.awt.Color(255, 255, 255));
        customerAddressField.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        customerAddressField.setPhColor(new java.awt.Color(255, 255, 255));
        customerAddressField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customerAddressFieldActionPerformed(evt);
            }
        });

        addlabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        addlabel.setForeground(new java.awt.Color(255, 255, 255));
        addlabel.setText("Address:");

        addItemButton.setBackground(new java.awt.Color(255, 153, 0));
        addItemButton.setText("Add Item");
        addItemButton.setColorHover(new java.awt.Color(255, 204, 102));
        addItemButton.setColorTextHover(new java.awt.Color(204, 102, 0));
        addItemButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addItemButtonMouseClicked(evt);
            }
        });
        addItemButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addItemButtonActionPerformed(evt);
            }
        });

        submitorderButton.setBackground(new java.awt.Color(255, 153, 0));
        submitorderButton.setText("Submit Order");
        submitorderButton.setColorHover(new java.awt.Color(255, 204, 102));
        submitorderButton.setColorTextHover(new java.awt.Color(204, 102, 0));
        submitorderButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                submitorderButtonMouseClicked(evt);
            }
        });
        submitorderButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitorderButtonActionPerformed(evt);
            }
        });

        quantityField.setBackground(new java.awt.Color(102, 51, 0));
        quantityField.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(255, 255, 255)));
        quantityField.setForeground(new java.awt.Color(255, 255, 255));
        quantityField.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        quantityField.setPhColor(new java.awt.Color(255, 255, 255));
        quantityField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quantityFieldActionPerformed(evt);
            }
        });

        priceField.setBackground(new java.awt.Color(102, 51, 0));
        priceField.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(255, 255, 255)));
        priceField.setForeground(new java.awt.Color(255, 255, 255));
        priceField.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        priceField.setPhColor(new java.awt.Color(255, 255, 255));
        priceField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                priceFieldActionPerformed(evt);
            }
        });

        b5.setBackground(new java.awt.Color(255, 153, 0));
        b5.setText("Back");
        b5.setColorHover(new java.awt.Color(255, 204, 102));
        b5.setColorTextHover(new java.awt.Color(204, 102, 0));
        b5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                b5MouseClicked(evt);
            }
        });
        b5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b5ActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/Screenshot_2025-05-19_155727-removebg-preview.png"))); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout kGradientPanel2Layout = new javax.swing.GroupLayout(kGradientPanel2);
        kGradientPanel2.setLayout(kGradientPanel2Layout);
        kGradientPanel2Layout.setHorizontalGroup(
            kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 758, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21)
                    .addComponent(customerNameField1, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(phoneNumberField, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addlabel)
                    .addComponent(customerAddressField, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(itemSelection, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(quantityField, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(priceField, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addGap(298, 298, 298)
                .addComponent(totalLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addComponent(addItemButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(submitorderButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addGap(201, 201, 201)
                .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        kGradientPanel2Layout.setVerticalGroup(
            kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addGroup(kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(kGradientPanel2Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLabel21)
                        .addGap(6, 6, 6)
                        .addComponent(customerNameField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel22)
                        .addGap(6, 6, 6)
                        .addComponent(phoneNumberField, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(addlabel)
                        .addGap(12, 12, 12)
                        .addComponent(customerAddressField, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(65, 65, 65)
                .addGroup(kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(kGradientPanel2Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(itemSelection, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quantityField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(priceField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addComponent(totalLabel)
                .addGap(34, 34, 34)
                .addGroup(kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addItemButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(submitorderButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getContentPane().add(kGradientPanel2, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void itemSelectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemSelectionActionPerformed
        // TODO add your handling code here:
         // This method is triggered when an item is selected from the dropdown
         String selectedItem = (String) itemSelection.getSelectedItem();
    System.out.println("Selected Item: " + selectedItem);
    if (!isInitializing && selectedItem != null) {
        updatePriceField(selectedItem);
    }
    }//GEN-LAST:event_itemSelectionActionPerformed

    private void updatePriceField(String itemName) { // Paste this method here
        double price = -1;
    Connection conn = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    try {
        conn = DBConnection.getConnection();
        stmt = conn.prepareStatement("SELECT price FROM items WHERE name = ?");
        stmt.setString(1, itemName);
        rs = stmt.executeQuery();
        if (rs.next()) {
            priceField.setText(String.valueOf(rs.getDouble("price")));
        } else {
            priceField.setText("");
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error retrieving item price.", "Database Error", JOptionPane.ERROR_MESSAGE);
        priceField.setText("");
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    }
    private void addItemButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addItemButtonMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_addItemButtonMouseClicked

    private void addItemButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addItemButtonActionPerformed
        // TODO add your handling code here:
            String itemName = (String) itemSelection.getSelectedItem();
    String quantityText = quantityField.getText();

    try {
        int quantity = Integer.parseInt(quantityText);
        double price = getItemPrice(itemName); // Implement this method

        if (price != -1) {
            itemSelections.add(new ItemSelection(itemName, quantity, price));
            JOptionPane.showMessageDialog(this, "Item Added: " + itemName + " x" + quantity + " at Rs" + String.format("%.2f", price));
            // Optionally clear the quantity field after adding
            quantityField.setText("");

            // Update the total
            orderTotal += (quantity * price);
            totalLabel.setText("Total: Rs" + String.format("%.2f", orderTotal));

        } else {
            JOptionPane.showMessageDialog(this, "Error retrieving price for " + itemName, "Database Error", JOptionPane.ERROR_MESSAGE);
        }

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Please enter a valid quantity.");
    }
    }//GEN-LAST:event_addItemButtonActionPerformed

    private void submitorderButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_submitorderButtonMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_submitorderButtonMouseClicked

    private void submitorderButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitorderButtonActionPerformed
        // TODO add your handling code here:
         String name = customerNameField1.getText();
        String phone = phoneNumberField.getText();
        String address = customerAddressField.getText();

        if (name.isEmpty() || phone.isEmpty() || address.isEmpty() || itemSelections.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in customer details and add at least one item.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false); // Start transaction

            // Insert customer
            String customerQuery = "INSERT INTO customers (name, phone_number, address) VALUES (?, ?, ?)";
            PreparedStatement customerStmt = conn.prepareStatement(customerQuery, Statement.RETURN_GENERATED_KEYS);
            customerStmt.setString(1, name);
            customerStmt.setString(2, phone);
            customerStmt.setString(3, address);
            customerStmt.executeUpdate();

            ResultSet customerRs = customerStmt.getGeneratedKeys();
            int customerId = -1;
            if (customerRs.next()) {
                customerId = customerRs.getInt(1);
            }
            customerStmt.close();

            if (customerId != -1) {
                // Insert order
                String orderQuery = "INSERT INTO orders (customer_id) VALUES (?)";
                PreparedStatement orderStmt = conn.prepareStatement(orderQuery, Statement.RETURN_GENERATED_KEYS);
                orderStmt.setInt(1, customerId);
                orderStmt.executeUpdate();

                ResultSet orderRs = orderStmt.getGeneratedKeys();
                int orderId = -1;
                if (orderRs.next()) {
                    orderId = orderRs.getInt(1);
                }
                orderStmt.close();

                if (orderId != -1) {
                    // Insert order items
                    String orderItemQuery = "INSERT INTO order_items (order_id, item_id, quantity, price) VALUES (?, (SELECT item_id FROM items WHERE name = ?), ?, ?)";
                    PreparedStatement orderItemStmt = conn.prepareStatement(orderItemQuery);
                    for (ItemSelection selection : itemSelections) {
                        orderItemStmt.setInt(1, orderId);
                        orderItemStmt.setString(2, selection.name);
                        orderItemStmt.setInt(3, selection.quantity);
                        orderItemStmt.setDouble(4, selection.price);
                        orderItemStmt.executeUpdate();
                    }
                    orderItemStmt.close();

                    conn.commit();
                    orderTotal = 0.0; // Reset the total
                    totalLabel.setText("Total: Rs0.00");
                    JOptionPane.showMessageDialog(this, "Order placed successfully!");

                    // Clear the form and item selections
                    itemSelections.clear();
                    customerNameField1.setText("");
                    phoneNumberField.setText("");
                    customerAddressField.setText("");
                    quantityField.setText("");
                    priceField.setText("");

                } else {
                    conn.rollback();
                    JOptionPane.showMessageDialog(this, "Error creating order.", "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                conn.rollback();
                JOptionPane.showMessageDialog(this, "Error creating customer.", "Database Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex) {
            try {
                if (DBConnection.getConnection() != null) {
                    DBConnection.getConnection().rollback(); // Rollback on error
                }
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error rolling back transaction.", "Database Error", JOptionPane.ERROR_MESSAGE);
            }
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error placing order.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_submitorderButtonActionPerformed

    private void quantityFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quantityFieldActionPerformed
        // TODO add your handling code here:
           // TODO add your handling code here:
        // This method is triggered when Enter is pressed in the quantity field.
        // You can validate if the entered quantity is a number.
        try {
            int quantity = Integer.parseInt(quantityField.getText());
            System.out.println("Quantity Entered: " + quantity);
        } catch (NumberFormatException e) {
            System.out.println("Invalid quantity entered!");
        }
    }//GEN-LAST:event_quantityFieldActionPerformed

    private void priceFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_priceFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_priceFieldActionPerformed

    private void b5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b5MouseClicked
        // TODO add your handling code here:
        Main mainWindow = new Main();
        mainWindow.setVisible(true);
        this.dispose(); // or this.setVisible(false);
    }//GEN-LAST:event_b5MouseClicked

    private void b5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_b5ActionPerformed

    private void phoneNumberFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneNumberFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phoneNumberFieldActionPerformed

    private void customerAddressFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customerAddressFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_customerAddressFieldActionPerformed

    private void customerNameField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customerNameField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_customerNameField1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(orderForm1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(orderForm1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(orderForm1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(orderForm1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new orderForm1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private rojerusan.RSButtonHover addItemButton;
    private javax.swing.JLabel addlabel;
    private rojerusan.RSButtonHover b5;
    private app.bolivia.swing.JCTextField customerAddressField;
    private app.bolivia.swing.JCTextField customerNameField1;
    private javax.swing.JComboBox<String> itemSelection;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private com.k33ptoo.components.KGradientPanel kGradientPanel2;
    private app.bolivia.swing.JCTextField phoneNumberField;
    private app.bolivia.swing.JCTextField priceField;
    private app.bolivia.swing.JCTextField quantityField;
    private rojerusan.RSButtonHover submitorderButton;
    private javax.swing.JLabel totalLabel;
    // End of variables declaration//GEN-END:variables
}
