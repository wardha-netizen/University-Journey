package dummy;

import javax.swing.table.DefaultTableModel;
import database.DBConnection;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class OrderManagementForm extends JFrame {
    private JTable orderTable;
    private JButton updateStatusButton, printReceiptButton, deleteOrderButton;
    private JTextField searchField;
    private JButton searchButton;
    private DefaultTableModel model;

    public OrderManagementForm() {
        setTitle("Order Management");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] columnNames = {"Order ID", "Customer", "Status"};
        model = new DefaultTableModel(columnNames, 0);
        orderTable = new JTable(model);
        loadOrders("");

        // Buttons
        updateStatusButton = new JButton("Update Status");
        printReceiptButton = new JButton("Print Receipt");
        deleteOrderButton = new JButton("Delete Order");

        updateStatusButton.addActionListener(e -> updateOrderStatus());
        printReceiptButton.addActionListener(e -> printReceipt());
        deleteOrderButton.addActionListener(e -> deleteOrder());

        // Search bar
        searchField = new JTextField(20);
        searchButton = new JButton("Search");
        searchButton.addActionListener(e -> searchOrders());

        JPanel topPanel = new JPanel();
            topPanel.add(new JLabel("Search:"));
            topPanel.add(searchField);
            topPanel.add(searchButton);

        JButton resetButton = new JButton("Reset");
            resetButton.addActionListener(e -> {
            searchField.setText("");
            loadOrders("");
        });
        topPanel.add(resetButton);


        JPanel buttonPanel = new JPanel();
        buttonPanel.add(updateStatusButton);
        buttonPanel.add(printReceiptButton);
        buttonPanel.add(deleteOrderButton);

        setLayout(new BorderLayout());
        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(orderTable), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void loadOrders(String keyword) {
        model.setRowCount(0); // clear old data
        try (Connection conn = DBConnection.getConnection()) {
            String query;
            PreparedStatement stmt;

            if (keyword.isEmpty()) {
                query = "SELECT orders.order_id, customers.name, orders.status " +
                        "FROM orders " +
                        "JOIN customers ON orders.customer_id = customers.customer_id";
                stmt = conn.prepareStatement(query);
            } else {
                query = "SELECT orders.order_id, customers.name, orders.status " +
                        "FROM orders " +
                        "JOIN customers ON orders.customer_id = customers.customer_id " +
                        "WHERE customers.name LIKE ? OR orders.order_id LIKE ?";
                stmt = conn.prepareStatement(query);
                stmt.setString(1, "%" + keyword + "%");
                stmt.setString(2, "%" + keyword + "%");
            }

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("order_id"),
                    rs.getString("name"),
                    rs.getString("status")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
    }
}


    private void updateOrderStatus() {
        int selectedRow = orderTable.getSelectedRow();
        if (selectedRow != -1) {
            int orderId = (int) orderTable.getValueAt(selectedRow, 0);

            String[] statuses = {"Pending", "Processing", "Completed", "Cancelled"};
            String newStatus = (String) JOptionPane.showInputDialog(this, "Select new status:", 
                                        "Update Status", JOptionPane.PLAIN_MESSAGE, null, statuses, statuses[0]);

            if (newStatus != null) {
                try (Connection conn = DBConnection.getConnection()) {
                    String query = "UPDATE orders SET status = ? WHERE order_id = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setString(1, newStatus);
                    stmt.setInt(2, orderId);
                    stmt.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Order status updated!");
                    loadOrders(searchField.getText());
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error updating status.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an order to update.");
        }
    }

    private void printReceipt() {
        int selectedRow = orderTable.getSelectedRow();
        if (selectedRow != -1) {
            int orderId = (int) orderTable.getValueAt(selectedRow, 0);

            try (Connection conn = DBConnection.getConnection()) {
                // Fetch general order info
                String query = "SELECT o.order_id, c.name, c.phone_number, c.address, o.status, o.order_date " +
                               "FROM orders o JOIN customers c ON o.customer_id = c.customer_id " +
                               "WHERE o.order_id = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, orderId);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    StringBuilder details = new StringBuilder();
                    details.append("Order ID: ").append(rs.getInt("order_id")).append("\n");
                    details.append("Customer Name: ").append(rs.getString("name")).append("\n");
                    details.append("Phone: ").append(rs.getString("phone_number")).append("\n");
                    details.append("Address: ").append(rs.getString("address")).append("\n");
                    details.append("Status: ").append(rs.getString("status")).append("\n");
                    details.append("Order Date: ").append(rs.getTimestamp("order_date")).append("\n\n");
               

                    // Fetch items
                    String itemsQuery = "SELECT i.name, oi.quantity, oi.price " +
                                        "FROM order_items oi JOIN items i ON oi.item_id = i.item_id " +
                                        "WHERE oi.order_id = ?";
                    PreparedStatement itemsStmt = conn.prepareStatement(itemsQuery);
                    itemsStmt.setInt(1, orderId);
                    ResultSet itemsRs = itemsStmt.executeQuery();

                    details.append("Items:\n");
                    double totalPrice = 0;
                    int totalItems = 0;
                    while (itemsRs.next()) {
                        String itemName = itemsRs.getString("name");
                        int quantity = itemsRs.getInt("quantity");
                        double price = itemsRs.getDouble("price");
                        double itemTotal = quantity * price;

                        details.append("- ").append(itemName)
                               .append(": ").append(quantity)
                               .append(" x ").append(price)
                               .append(" = ").append(itemTotal).append("\n");

                        totalItems += quantity;
                        totalPrice += itemTotal;
                    }

                    details.append("\nTotal Items: ").append(totalItems);
                    details.append("\nTotal Price: ").append(totalPrice);

                    // Show in pop-up
                    JTextArea textArea = new JTextArea(details.toString(), 20, 40);
                    textArea.setEditable(false);
                    JOptionPane.showMessageDialog(this, new JScrollPane(textArea), 
                            "Order Details", JOptionPane.INFORMATION_MESSAGE);
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error fetching order details.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an order to print receipt.");
        }
    }

    private void deleteOrder() {
        int selectedRow = orderTable.getSelectedRow();
        if (selectedRow != -1) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this order?", 
                                                        "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                int orderId = (int) orderTable.getValueAt(selectedRow, 0);

                try (Connection conn = DBConnection.getConnection()) {
                    // First delete order_items
                    String deleteItemsQuery = "DELETE FROM order_items WHERE order_id = ?";
                    PreparedStatement deleteItemsStmt = conn.prepareStatement(deleteItemsQuery);
                    deleteItemsStmt.setInt(1, orderId);
                    deleteItemsStmt.executeUpdate();

                    // Then delete order
                    String deleteOrderQuery = "DELETE FROM orders WHERE order_id = ?";
                    PreparedStatement deleteOrderStmt = conn.prepareStatement(deleteOrderQuery);
                    deleteOrderStmt.setInt(1, orderId);
                    deleteOrderStmt.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Order deleted successfully!");
                    loadOrders(searchField.getText());
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error deleting order.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an order to delete.");
        }
    }

    private void searchOrders() {
        String keyword = searchField.getText().trim();
        loadOrders(keyword);
}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OrderManagementForm());
    }
}
