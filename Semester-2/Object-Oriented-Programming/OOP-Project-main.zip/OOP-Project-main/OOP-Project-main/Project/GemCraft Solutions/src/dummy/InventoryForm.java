package dummy;

import database.DBConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class InventoryForm extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private JButton addButton, updateButton, deleteButton, refreshButton;
    private JPanel buttonPanel;

    public InventoryForm() {
        setTitle("Inventory Management");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Description", "Price", "Quantity"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        addButton = new JButton("Add Item");
        updateButton = new JButton("Update Item");
        deleteButton = new JButton("Delete Item");
        refreshButton = new JButton("Refresh");

        buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(e -> addItem());
        updateButton.addActionListener(e -> updateItem());
        deleteButton.addActionListener(e -> deleteItem());
        refreshButton.addActionListener(e -> loadInventory());

        loadInventory();
        setVisible(true);
    }

    private void loadInventory() {
        tableModel.setRowCount(0); // Clear existing data
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM items")) {

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("item_id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("quantity")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading inventory: " + e.getMessage());
        }
    }

    private void addItem() {
        JTextField nameField = new JTextField();
        JTextField descField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField quantityField = new JTextField();

        Object[] fields = {
                "Name:", nameField,
                "Description:", descField,
                "Price:", priceField,
                "Quantity:", quantityField
        };

        int option = JOptionPane.showConfirmDialog(this, fields, "Add New Item", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                         "INSERT INTO items (name, description, price, quantity) VALUES (?, ?, ?, ?)")) {

                stmt.setString(1, nameField.getText());
                stmt.setString(2, descField.getText());
                stmt.setDouble(3, Double.parseDouble(priceField.getText()));
                stmt.setInt(4, Integer.parseInt(quantityField.getText()));

                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Item added successfully!");
                loadInventory();
            } catch (SQLException | NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Error adding item: " + e.getMessage());
            }
        }
    }

    private void updateItem() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            int itemId = (int) tableModel.getValueAt(selectedRow, 0);

            String currentName = (String) tableModel.getValueAt(selectedRow, 1);
            String currentDesc = (String) tableModel.getValueAt(selectedRow, 2);
            double currentPrice = (double) tableModel.getValueAt(selectedRow, 3);
            int currentQuantity = (int) tableModel.getValueAt(selectedRow, 4);

            JTextField nameField = new JTextField(currentName);
            JTextField descField = new JTextField(currentDesc);
            JTextField priceField = new JTextField(String.valueOf(currentPrice));
            JTextField quantityField = new JTextField(String.valueOf(currentQuantity));

            Object[] fields = {
                    "Name:", nameField,
                    "Description:", descField,
                    "Price:", priceField,
                    "Quantity:", quantityField
            };

            int option = JOptionPane.showConfirmDialog(this, fields, "Update Item", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement stmt = conn.prepareStatement(
                             "UPDATE items SET name = ?, description = ?, price = ?, quantity = ? WHERE item_id = ?")) {

                    stmt.setString(1, nameField.getText());
                    stmt.setString(2, descField.getText());
                    stmt.setDouble(3, Double.parseDouble(priceField.getText()));
                    stmt.setInt(4, Integer.parseInt(quantityField.getText()));
                    stmt.setInt(5, itemId);

                    stmt.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Item updated successfully!");
                    loadInventory();
                } catch (SQLException | NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Error updating item: " + e.getMessage());
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an item to update.");
        }
    }

    private void deleteItem() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            int itemId = (int) tableModel.getValueAt(selectedRow, 0);
            
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this item?", 
                    "Confirm Delete", JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                try (Connection conn = DBConnection.getConnection()) {
                    // Check if the item is present in any order_items
                    String checkOrderItemsQuery = "SELECT COUNT(*) FROM order_items WHERE item_id = ?";
                    PreparedStatement checkOrderItemsStmt = conn.prepareStatement(checkOrderItemsQuery);
                    checkOrderItemsStmt.setInt(1, itemId);
                    ResultSet orderItemsRs = checkOrderItemsStmt.executeQuery();
                    orderItemsRs.next();
                    int orderItemCount = orderItemsRs.getInt(1);
                    
                    if (orderItemCount > 0) {
                        JOptionPane.showMessageDialog(this, "Cannot delete item. This item is included in existing orders. Delete the associated orders first.", "Deletion Error", JOptionPane.ERROR_MESSAGE);
                        return; // Stop the deletion process
                    }
                    
                    // If no associated order_items, proceed with deletion from items
                    String deleteQuery = "DELETE FROM items WHERE item_id = ?";
                    PreparedStatement deleteStmt = conn.prepareStatement(deleteQuery);
                    int rowsAffected = deleteStmt.executeUpdate();

                    if (rowsAffected > 0) {
                        tableModel.removeRow(selectedRow);
                        JOptionPane.showMessageDialog(this, "Item deleted successfully!");
                    } else {
                        JOptionPane.showMessageDialog(this, "Error: Item not found in the database.", "Deletion Error", JOptionPane.ERROR_MESSAGE);
                    }
                    
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Error deleting item: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);

                } finally {
                    loadInventory(); 
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an item to delete.");
        }
    }
}
